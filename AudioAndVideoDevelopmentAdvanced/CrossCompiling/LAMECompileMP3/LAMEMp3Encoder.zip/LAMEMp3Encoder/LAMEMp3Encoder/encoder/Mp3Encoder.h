//
//  Mp3Encoder.h
//  LAMEMp3Encoder
//
//  Created by 冯才凡 on 2020/7/16.
//  Copyright © 2020 冯才凡. All rights reserved.
//

#ifndef Mp3Encoder_h
#define Mp3Encoder_h

#import <Foundation/Foundation.h>

@interface Mp3EncoderOC : NSObject

-(void)encoder;

@end




#endif /* Mp3Encoder_h */
